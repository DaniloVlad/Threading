#include <stdio.h>

int main() {
	printf("From external program B: Hello World..\n");
	return 0;
}
